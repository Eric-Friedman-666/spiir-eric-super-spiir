#ifndef __CUDA_DEBUG_H__
#define __CUDA_DEBUG_H__

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

#define DEBUG 1
#ifdef DEBUG
#define CUDA_CHECK(value)                                                      \
    {                                                                          \
        cudaError_t _m_cudaStat = value;                                       \
        if (_m_cudaStat != cudaSuccess) {                                      \
            fprintf(stderr,                                                    \
                    "CUDA_CHECK: Error '%s' at line '%d' in file '%s'\n",      \
                    cudaGetErrorString(_m_cudaStat), __LINE__, __FILE__);      \
            exit(1);                                                           \
        }                                                                      \
    }

#else
#define CUDA_CHECK(value)                                                      \
    { value; }
#endif
#endif
