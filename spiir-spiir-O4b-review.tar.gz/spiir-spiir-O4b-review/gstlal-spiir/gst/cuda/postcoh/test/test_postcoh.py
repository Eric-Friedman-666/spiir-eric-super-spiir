#!/usr/bin/env python
# FIXME: This scripts does not run because postcoh->stream_id is never set.

import gi

gi.require_version("Gst", "1.0")
from gi.repository import GObject, Gst

Gst.init(None)

from gstlal import pipeparts

pipeline = Gst.Pipeline("test_postcoh")
mainloop = GObject.MainLoop()

src1 = pipeparts.mkaudiotestsrc(pipeline, wave=9)
src1 = pipeparts.mkcapsfilter(pipeline, src1,
                              "audio/x-raw, width=32, channels=2, rate=4096")
src2 = pipeparts.mkaudiotestsrc(pipeline, wave=9)
src2 = pipeparts.mkcapsfilter(pipeline, src2,
                              "audio/x-raw, width=32, channels=2, rate=4096")
src3 = pipeparts.mkaudiotestsrc(pipeline, wave=9)
src3 = pipeparts.mkcapsfilter(pipeline, src3,
                              "audio/x-raw, width=32, channels=2, rate=4096")
src4 = pipeparts.mkaudiotestsrc(pipeline, wave=9)
src4 = pipeparts.mkcapsfilter(pipeline, src4,
                              "audio/x-raw, width=32, channels=2, rate=4096")

postcoh = Gst.ElementFactory.make("cuda_postcoh", None)
postcoh.set_property("detrsp-fname", "H1L1V1K1_skymap.xml")
postcoh.set_property(
    "autocorrelation-fname",
    "L1:H1bank.xml.gz,H1:H1bank.xml.gz,V1:H1bank.xml.gz,K1:H1bank.xml.gz")
postcoh.set_property("hist-trials", 1)
postcoh.set_property("snglsnr-thresh", 1.0)
pipeline.add(postcoh)
src1.link_pads(None, postcoh, "H1")
src2.link_pads(None, postcoh, "L1")
src3.link_pads(None, postcoh, "V1")
src4.link_pads(None, postcoh, "K1")

postcoh = pipeparts.mkcapsfilter(
    pipeline, postcoh, "audio/x-raw, width=32, channels=2, rate=4096")
sink = Gst.ElementFactory.make("fakesink", None)
pipeline.add(sink)
postcoh.link(sink)

pipeline.set_state(Gst.State.PLAYING)

mainloop.run()
