/*
 * Copyright (C) 2014 Qi Chu <qi.chu@ligo.org>
 * most of this file is copied from gstfilesink.c 0.10.32 and 0.10.36
 *
 * Copyright (C) 1999,2000 Erik Walthinsen <omega@cse.ogi.edu>
 *					2000 Wim Taymans <wtay@chello.be>
 *					2006 Wim Taymans <wim@fluendo.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/* This element will synchronize the snr sequencies from all detectors, find
 * peaks from all detectors and for each peak, do null stream analysis.
 */

#include "postcoh_filesink.h"

#include "postcohtable_utils.h"

#include <errno.h>
#include <glib.h>
#include <glib/gstdio.h>
#include <gst/gst.h>
#include <math.h>
#include <string.h>

#define EPSILON 5.0
enum { PROP_0, PROP_LOCATION, PROP_COMPRESS, PROP_SNAPSHOT_INTERVAL };

/* The following content is mostly copied from gstfilesink.c */

#if 0
/* Copy of glib's g_fopen due to win32 libc/cross-DLL brokenness: we can't
 * use the 'file pointer' opened in glib (and returned from this function)
 * in this library, as they may have unrelated C runtimes. */
static FILE *
gst_fopen (const gchar * filename, const gchar * mode)
{
#ifdef G_OS_WIN32
  wchar_t *wfilename = g_utf8_to_utf16 (filename, -1, NULL, NULL, NULL);
  wchar_t *wmode;
  FILE *retval;
  int save_errno;

  if (wfilename == NULL) {
	errno = EINVAL;
	return NULL;
  }

  wmode = g_utf8_to_utf16 (mode, -1, NULL, NULL, NULL);

  if (wmode == NULL) {
	g_free (wfilename);
	errno = EINVAL;
	return NULL;
  }

  retval = _wfopen (wfilename, wmode);
  save_errno = errno;

  g_free (wfilename);
  g_free (wmode);

  errno = save_errno;
  return retval;
#else
  return fopen (filename, mode);
#endif
}
#endif

static void postcoh_filesink_dispose(GObject *object);

static void postcoh_filesink_set_property(GObject *object,
                                          guint prop_id,
                                          const GValue *value,
                                          GParamSpec *pspec);
static void postcoh_filesink_get_property(GObject *object,
                                          guint prop_id,
                                          GValue *value,
                                          GParamSpec *pspec);

// We don't need file operations any more as is taken care of by xml writer
// static gboolean postcoh_filesink_open_file (PostcohFilesink * sink);
// static void postcoh_filesink_close_file (PostcohFilesink * sink);

static gboolean postcoh_filesink_start(GstBaseSink *sink);
static gboolean postcoh_filesink_stop(GstBaseSink *sink);
static gboolean postcoh_filesink_sink_event(GstBaseSink *sink, GstEvent *event);
static GstFlowReturn postcoh_filesink_render(GstBaseSink *sink,
                                             GstBuffer *buffer);

// static gboolean postcoh_filesink_do_seek (PostcohFilesink * filesink,
//	guint64 new_offset);
// static gboolean postcoh_filesink_get_current_offset (PostcohFilesink *
// filesink, 	guint64 * p_pos);

// static gboolean postcoh_filesink_query (GstBaseSink * bsink, GstQuery *
// query);

static void postcoh_filesink_uri_handler_init(gpointer g_iface,
                                              gpointer iface_data);

#define GST_CAT_DEFAULT postcoh_filesink_debug
GST_DEBUG_CATEGORY_STATIC(GST_CAT_DEFAULT);

G_DEFINE_TYPE_WITH_CODE(
  PostcohFilesink,
  postcoh_filesink,
  GST_TYPE_BASE_SINK,
  G_IMPLEMENT_INTERFACE(GST_TYPE_URI_HANDLER,
                        postcoh_filesink_uri_handler_init);
  GST_DEBUG_CATEGORY_INIT(
    GST_CAT_DEFAULT, "postcoh filesink", 0, "postcoh filesink element"))

static void postcoh_filesink_class_init(PostcohFilesinkClass *klass) {
    GObjectClass *gobject_class = G_OBJECT_CLASS(klass);

    gobject_class->dispose = postcoh_filesink_dispose;

    gobject_class->set_property = postcoh_filesink_set_property;
    gobject_class->get_property = postcoh_filesink_get_property;

    g_object_class_install_property(
      gobject_class, PROP_LOCATION,
      g_param_spec_string("location", "File Location",
                          "Location prefix of the file to write", NULL,
                          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    g_object_class_install_property(
      gobject_class, PROP_COMPRESS,
      g_param_spec_int("compression", "Whether to compress or not",
                       "(0) Non-compression, (1) Compression", 0, 1, 1,
                       G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    g_object_class_install_property(
      gobject_class, PROP_SNAPSHOT_INTERVAL,
      g_param_spec_int(
        "snapshot-interval", "How often to store postcoh table",
        "How often to store postcoh table: (0) At the end, (N) Every N seconds",
        0, G_MAXINT, 0, G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    GstBaseSinkClass *gstbasesink_class = GST_BASE_SINK_CLASS(klass);

    gstbasesink_class->start = GST_DEBUG_FUNCPTR(postcoh_filesink_start);
    gstbasesink_class->stop  = GST_DEBUG_FUNCPTR(postcoh_filesink_stop);
    //  gstbasesink_class->query = GST_DEBUG_FUNCPTR (postcoh_filesink_query);
    gstbasesink_class->render = GST_DEBUG_FUNCPTR(postcoh_filesink_render);
    gstbasesink_class->event  = GST_DEBUG_FUNCPTR(postcoh_filesink_sink_event);

    GstElementClass *gst_element_class = GST_ELEMENT_CLASS(klass);

    gst_element_class_set_metadata(
      gst_element_class, "Postcoh File Sink", "Sink/File",
      "Write postcoh tables to a xml file", "Qi Chu <qi.chu at ligo dot org>");

    GstCaps *template_caps = gst_caps_from_string("application/x-lal-postcoh");

    gst_element_class_add_pad_template(
      gst_element_class, gst_pad_template_new("sink", GST_PAD_SINK,
                                              GST_PAD_ALWAYS, template_caps));

    gst_caps_unref(template_caps);
}

static void postcoh_filesink_init(PostcohFilesink *sink) {
    sink->filename = NULL;
    sink->file     = NULL;
    sink->uri      = NULL;

    sink->cur_filename = NULL;
    gst_base_sink_set_sync(GST_BASE_SINK(sink), FALSE);
}

static void postcoh_filesink_dispose(GObject *object) {
    PostcohFilesink *sink = POSTCOH_FILESINK(object);

    G_OBJECT_CLASS(postcoh_filesink_parent_class)->dispose(object);

    if (sink->uri) {
        g_free(sink->uri);
        sink->uri = NULL;
    }
    if (sink->filename) {
        g_free(sink->filename);
        sink->filename = NULL;
    }
}

static gboolean postcoh_filesink_set_location(PostcohFilesink *sink,
                                              const gchar *location) {
    if (sink->file) goto was_open;

    g_free(sink->filename);
    g_free(sink->uri);
    if (location != NULL) {
        /* we store the filename as we received it from the application. On
         * Windows this should be in UTF8 */
        sink->filename = g_strdup(location);
        sink->uri      = gst_filename_to_uri(location, NULL);
        //	sink->uri = g_filename_to_uri (location, NULL, NULL);
        //	sink->uri = gst_uri_construct ("file", sink->filename);
        //	printf ("filename : %s", sink->filename);
        //	printf ("uri	  : %s", sink->uri);
    } else {
        sink->filename = NULL;
        sink->uri      = NULL;
    }

    return TRUE;

    /* ERRORS */
was_open : {
    g_warning("Changing the `location' property on filesink when a file is "
              "open is not supported.");
    return FALSE;
}
}

static void postcoh_filesink_set_property(GObject *object,
                                          guint prop_id,
                                          const GValue *value,
                                          GParamSpec *pspec) {
    PostcohFilesink *sink = POSTCOH_FILESINK(object);

    switch (prop_id) {
    case PROP_LOCATION:
        postcoh_filesink_set_location(sink, g_value_get_string(value));
        break;
    case PROP_COMPRESS: sink->compress = g_value_get_int(value); break;
    case PROP_SNAPSHOT_INTERVAL:
        sink->snapshot_interval = g_value_get_int(value);
        break;
    default: G_OBJECT_WARN_INVALID_PROPERTY_ID(object, prop_id, pspec); break;
    }
}

static void postcoh_filesink_get_property(GObject *object,
                                          guint prop_id,
                                          GValue *value,
                                          GParamSpec *pspec) {
    PostcohFilesink *sink = POSTCOH_FILESINK(object);

    switch (prop_id) {
    case PROP_LOCATION: g_value_set_string(value, sink->filename); break;
    case PROP_COMPRESS: g_value_set_int(value, sink->compress); break;
    case PROP_SNAPSHOT_INTERVAL:
        g_value_set_int(value, sink->snapshot_interval);
        break;
    default: G_OBJECT_WARN_INVALID_PROPERTY_ID(object, prop_id, pspec); break;
    }
}
#if 0
static gboolean
postcoh_filesink_open_file (PostcohFilesink * sink)
{
  gint mode;

  /* open the file */
  if (sink->filename == NULL || sink->filename[0] == '\0')
	goto no_filename;

  sink->file = gst_fopen (sink->filename, "wb");
  if (sink->file == NULL)
	goto open_failed;

  return TRUE;

  /* ERRORS */
no_filename:
  {
	GST_ELEMENT_ERROR (sink, RESOURCE, NOT_FOUND,
		(_("No file name specified for writing.")), (NULL));
	return FALSE;
  }
open_failed:
  {
	GST_ELEMENT_ERROR (sink, RESOURCE, OPEN_WRITE,
		(_("Could not open file \"%s\" for writing."), sink->filename),
		GST_ERROR_SYSTEM);
	return FALSE;
  }
}

static void
postcoh_filesink_close_file (PostcohFilesink * sink)
{
  if (sink->file) {
	if (fclose (sink->file) != 0)
	  goto close_failed;

	GST_DEBUG_OBJECT (sink, "closed file");
	sink->file = NULL;

  }
  return;

  /* ERRORS */
close_failed:
  {
	GST_ELEMENT_ERROR (sink, RESOURCE, CLOSE,
		(_("Error closing file \"%s\"."), sink->filename), GST_ERROR_SYSTEM);
	return;
  }
}
#endif

static gboolean postcoh_filesink_start_xml(PostcohFilesink *sink) {
    sink->writer =
      xmlNewTextWriterFilename(sink->cur_filename->str, sink->compress);
    xmlTextWriterPtr writer = sink->writer;
    if (writer == NULL) {
        printf("testXmlwriterFilename: Error creating the xml writer\n");
        return FALSE;
    }

    int rc;
    rc = xmlTextWriterSetIndent(writer, 1);
    rc = xmlTextWriterSetIndentString(writer, BAD_CAST "\t");

    /* Start the document with the xml default for the version,
     * encoding utf-8 and the default for the standalone
     * declaration. */
    rc = xmlTextWriterStartDocument(writer, NULL, MY_ENCODING, NULL);
    if (rc < 0) {
        printf("testXmlwriterFilename: Error at xmlTextWriterStartDocument\n");
        return FALSE;
    }

    rc = xmlTextWriterWriteDTD(
      writer, BAD_CAST "LIGO_LW", NULL,
      BAD_CAST
      "http://ldas-sw.ligo.caltech.edu/doc/ligolwAPI/html/ligolw_dtd.txt",
      NULL);
    if (rc < 0) {
        printf("testXmlwriterFilename: Error at xmlTextWriterWriteDTD\n");
        return FALSE;
    }

    /* Start an element named "LIGO_LW". Since thist is the first
     * element, this will be the root element of the document. */
    rc = xmlTextWriterStartElement(writer, BAD_CAST "LIGO_LW");
    if (rc < 0) {
        printf("testXmlwriterFilename: Error at xmlTextWriterStartElement\n");
        return FALSE;
    }

    /* Start an element named "LIGO_LW" as child of EXAMPLE. */
    rc = xmlTextWriterStartElement(writer, BAD_CAST "LIGO_LW");
    if (rc < 0) {
        printf("testXmlwriterFilename: Error at xmlTextWriterStartElement\n");
        return FALSE;
    }

    sink->xtable     = (XmlTable *)malloc(sizeof(XmlTable));
    XmlTable *xtable = sink->xtable;
    postcohtable_init(xtable);
    // Add the Table Node
    rc = xmlTextWriterStartElement(writer, BAD_CAST "Table");

    // Add Attribute "Name"
    rc = xmlTextWriterWriteAttribute(writer, BAD_CAST "Name",
                                     BAD_CAST xtable->tableName->str);

    // Write Column Nodes
    int i;
    for (i = 0; i < (int)xtable->names->len; ++i) {
        rc = xmlTextWriterStartElement(writer, BAD_CAST "Column");

        GString *colName = &g_array_index(xtable->names, GString, i);
        GString *type    = &g_array_index(xtable->type_names, GString, i);

        rc = xmlTextWriterWriteAttribute(writer, BAD_CAST "Type",
                                         BAD_CAST type->str);
        rc = xmlTextWriterWriteAttribute(writer, BAD_CAST "Name",
                                         BAD_CAST colName->str);

        rc = xmlTextWriterEndElement(writer);
    }

    // Write Stream Nodes
    rc = xmlTextWriterStartElement(writer, BAD_CAST "Stream");
    rc = xmlTextWriterWriteAttribute(writer, BAD_CAST "Delimiter",
                                     BAD_CAST xtable->delimiter->str);
    rc = xmlTextWriterWriteAttribute(writer, BAD_CAST "Type", BAD_CAST "Local");
    rc = xmlTextWriterWriteAttribute(writer, BAD_CAST "Name",
                                     BAD_CAST xtable->tableName->str);

    rc = xmlTextWriterWriteString(writer, BAD_CAST "\n");
    if (rc < 0) return FALSE;
    else
        return TRUE;
}

static gboolean postcoh_filesink_end_xml(PostcohFilesink *sink) {
    xmlTextWriterPtr writer = sink->writer;
    int rc                  = 0;

    /* for stream */
    rc = xmlTextWriterEndElement(writer);
    if (rc < 0) {
        printf("Error at xmlTextWriterEndElement\n");
        return FALSE;
    }

    /* for table */
    xmlTextWriterEndElement(writer);
    if (rc < 0) {
        printf("Error at xmlTextWriterEndElement\n");
        return FALSE;
    }

    /* for the whole document */
    xmlTextWriterEndDocument(writer);
    if (rc < 0) {
        printf("Error at xmlTextWriterEndDocument\n");
        return FALSE;
    }
    return TRUE;
}

static gboolean postcoh_filesink_cleanup_xml(PostcohFilesink *sink) {

    if (sink->writer) xmlFreeTextWriter(sink->writer);
    //  postcoh_filesink_close_file (sink);
    if (sink->xtable) {
        free(sink->xtable);
        sink->xtable = NULL;
    }
    if (sink->cur_filename) {
        g_string_free(sink->cur_filename, TRUE);
        sink->cur_filename = NULL;
    }
    return TRUE;
}

static GstFlowReturn
  postcoh_filesink_write_table_from_buf(PostcohFilesink *sink, GstBuffer *buf) {
    GstMapInfo mapInfo;
    gst_buffer_map(buf, &mapInfo, GST_MAP_READ);

    PostcohInspiralTable *table = (PostcohInspiralTable *)mapInfo.data;
    PostcohInspiralTable *table_end =
      (PostcohInspiralTable *)(mapInfo.data + mapInfo.size);

    XmlTable *xtable = sink->xtable;

    GST_LOG_OBJECT(sink, "start to write postcoh table");
    for (; table < table_end; table++) {
        GString *line = g_string_new("\t\t\t\t");
        postcohtable_set_line(line, table, xtable);
        int rc =
          xmlTextWriterWriteString(sink->writer, (const xmlChar *)line->str);
        if (rc < 0) {
            gst_buffer_unmap(buf, &mapInfo);
            return GST_FLOW_ERROR;
        }
        g_string_free(line, TRUE);
    }

    gst_buffer_unmap(buf, &mapInfo);

    GST_LOG_OBJECT(sink,
                   "Writen a buffer (%" G_GSIZE_FORMAT
                   " bytes) with timestamp %" GST_TIME_FORMAT
                   ", duration %" GST_TIME_FORMAT ", offset %" G_GUINT64_FORMAT
                   ", offset_end %" G_GUINT64_FORMAT,
                   gst_buffer_get_size(buf), GST_TIME_ARGS(GST_BUFFER_PTS(buf)),
                   GST_TIME_ARGS(GST_BUFFER_DURATION(buf)),
                   GST_BUFFER_OFFSET(buf), GST_BUFFER_OFFSET_END(buf));

    return GST_FLOW_OK;
}

/* handle events (search) */
static gboolean postcoh_filesink_sink_event(GstBaseSink *basesink,
                                            GstEvent *event) {
    GstEventType type;
    PostcohFilesink *sink;

    sink = POSTCOH_FILESINK(basesink);

    type = GST_EVENT_TYPE(event);

    switch (type) {
    case GST_EVENT_EOS:
        GST_LOG_OBJECT(sink, "EVENT EOS. Finish writing document");

        gboolean rt = postcoh_filesink_end_xml(sink);
        if (rt == FALSE) {
            GST_ERROR_OBJECT(sink, "postcoh xml end writing failed");
            return FALSE;
        }
        /* close current file */
        if (sink->writer) {
            xmlFreeTextWriter(sink->writer);
            sink->writer = NULL;
        }

        guint duration = (sink->t_end - sink->t_start) / GST_SECOND;
        if (duration != (unsigned)sink->snapshot_interval) {
            GString *new_filename = g_string_new(sink->uri);
            gint gps_time         = sink->t_start / GST_SECOND;
            g_string_append_printf(new_filename, "_%d_%d.xml.gz", gps_time,
                                   duration);
            /* rename does not recognize the first 7 chars "file://" so we need
             * to remove that */
            gchar *tmp_new_filename_str = g_strdup(&(new_filename->str[7]));
            gchar *tmp_cur_filename_str =
              g_strdup(&(sink->cur_filename->str[7]));
            /* rename the current file to a proper name */
            if (g_rename(tmp_cur_filename_str, tmp_new_filename_str) == -1) {
                perror("Error when renaming");
            }
            g_string_free(new_filename, TRUE);
            new_filename = NULL;
            g_free(tmp_new_filename_str);
            g_free(tmp_cur_filename_str);
        }
        break;
    default: break;
    }

    return GST_BASE_SINK_CLASS(postcoh_filesink_parent_class)
      ->event(basesink, event);
}

static GstFlowReturn postcoh_filesink_render(GstBaseSink *basesink,
                                             GstBuffer *buf) {
    PostcohFilesink *sink;
    sink        = POSTCOH_FILESINK(basesink);
    sink->t_end = GST_BUFFER_PTS(buf) + GST_BUFFER_DURATION(buf);

    if (!GST_CLOCK_TIME_IS_VALID(sink->t_start)) {
        sink->t_start = GST_BUFFER_PTS(buf);
        // This is the filename prefix.
        g_assert(sink->uri);
        sink->cur_filename = g_string_new(sink->uri);
        gint gps_time      = sink->t_start / GST_SECOND;
        if (sink->snapshot_interval)
            g_string_append_printf(sink->cur_filename, "_%d_%d.xml.gz",
                                   gps_time, sink->snapshot_interval);
        else
            g_string_append_printf(sink->cur_filename, "_%d_end.xml.gz",
                                   gps_time);

        gboolean rt = postcoh_filesink_start_xml(sink);
        if (rt == FALSE) {
            GST_ERROR_OBJECT(sink, "postcoh xml header writing failed");
            return GST_FLOW_ERROR;
        }
        GstFlowReturn rs = postcoh_filesink_write_table_from_buf(sink, buf);
        return rs;
    }

    GstClockTime t_cur = GST_BUFFER_PTS(buf);
    if (sink->snapshot_interval > 0
        && (t_cur - sink->t_start) / GST_SECOND
             > (unsigned)sink->snapshot_interval) {

        gboolean rt = postcoh_filesink_end_xml(sink);
        if (rt == FALSE) {
            GST_ERROR_OBJECT(sink, "postcoh xml end writing failed");
            return GST_FLOW_ERROR;
        }

        postcoh_filesink_cleanup_xml(sink);

        /* Create a new xml file for postcoh table */
        sink->t_start = t_cur;
        // This is the filename prefix.
        g_assert(sink->uri);
        sink->cur_filename = g_string_new(sink->uri);
        gint gps_time      = sink->t_start / GST_SECOND;
        g_string_append_printf(sink->cur_filename, "_%d_%d.xml.gz", gps_time,
                               sink->snapshot_interval);
        rt = postcoh_filesink_start_xml(sink);
        if (rt == FALSE) {
            GST_ERROR_OBJECT(sink, "postcoh xml header writing failed");
            return GST_FLOW_ERROR;
        }
    }
    GstFlowReturn rs = postcoh_filesink_write_table_from_buf(sink, buf);
    return rs;
}

static gboolean postcoh_filesink_start(GstBaseSink *basesink) {
    PostcohFilesink *sink = POSTCOH_FILESINK(basesink);
    sink->t_start         = GST_CLOCK_TIME_NONE;
    return TRUE;
}

static gboolean postcoh_filesink_stop(GstBaseSink *basesink) {

    PostcohFilesink *sink = POSTCOH_FILESINK(basesink);
    postcoh_filesink_cleanup_xml(sink);
    return TRUE;
}
/*** GSTURIHANDLER INTERFACE *************************************************/

static GstURIType postcoh_filesink_uri_get_type(GType type) {
    return GST_URI_SINK;
}

static const gchar *const *postcoh_filesink_uri_get_protocols(GType type) {
    static const gchar *const protocols[] = { "file", NULL };

    return protocols;
}

static gchar *postcoh_filesink_uri_get_uri(GstURIHandler *handler) {
    PostcohFilesink *sink = POSTCOH_FILESINK(handler);

    return g_string_new(sink->uri)->str;
}

static gboolean postcoh_filesink_uri_set_uri(GstURIHandler *handler,
                                             const gchar *uri,
                                             GError **error) {
    /* FIXME:  report errors via GError argument */

    gchar *location;
    gboolean ret;
    PostcohFilesink *sink = POSTCOH_FILESINK(handler);

    /* allow file://localhost/foo/bar by stripping localhost but fail
     * for every other hostname */
    if (g_str_has_prefix(uri, "file://localhost/")) {
        char *tmp;

        /* 16 == strlen ("file://localhost") */
        tmp = g_strconcat("file://", uri + 16, NULL);
        /* we use gst_uri_get_location() although we already have the
         * "location" with uri + 16 because it provides unescaping */
        location = gst_uri_get_location(tmp);
        g_free(tmp);
    } else if (strcmp(uri, "file://") == 0) {
        /* Special case for "file://" as this is used by some applications
         *  to test with gst_element_make_from_uri if there's an element
         *  that supports the URI protocol. */
        postcoh_filesink_set_location(sink, NULL);
        return TRUE;
    } else {
        location = gst_uri_get_location(uri);
    }

    if (!location) return FALSE;
    if (!g_path_is_absolute(location)) {
        g_free(location);
        return FALSE;
    }

    ret = postcoh_filesink_set_location(sink, location);
    g_free(location);

    return ret;
}

static void postcoh_filesink_uri_handler_init(gpointer g_iface,
                                              gpointer iface_data) {
    GstURIHandlerInterface *iface = (GstURIHandlerInterface *)g_iface;

    iface->get_type      = postcoh_filesink_uri_get_type;
    iface->get_protocols = postcoh_filesink_uri_get_protocols;
    iface->get_uri       = postcoh_filesink_uri_get_uri;
    iface->set_uri       = postcoh_filesink_uri_set_uri;
}
