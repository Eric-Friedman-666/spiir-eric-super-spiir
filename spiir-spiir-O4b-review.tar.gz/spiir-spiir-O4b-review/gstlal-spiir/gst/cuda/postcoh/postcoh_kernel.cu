/*
 * Copyright (C) 2014 Xiaoyang Guo, Xiangyu Guo, Qi Chu <qi.chu@ligo.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include <assert.h>
#include <cuda_debug.h>
#include <cuda_runtime.h>
#include <pipe_macro.h>
#include <stdio.h>

extern "C" {
#include <postcoh/postcoh_kernel.h>
}

#define WARP_SIZE        32
#define WARP_MASK        31
#define LOG_WARP_SIZE    5
#define ALL_THREADS_MASK 0xFFFFFFFF

#define MIN_EPSILON       1e-7
#define NSKY_REDUCE_RATIO 4

// Returns a wrapped index that can be safely used by the ring buffer.
__device__ static inline size_t ring_index(ptrdiff_t ind, ptrdiff_t len) {
    assert(len > 0);
    return ((ind % len) + len) % len;
}

__global__ void ker_coh_skymap(
  float *__restrict__ cohsnr_skymap, /* OUTPUT, of size (num_triggers *
                                        num_sky_directions) */
  float *__restrict__ nullsnr_skymap, /* OUTPUT, of size (num_triggers *
                                         num_sky_directions) */
  COMPLEX_F *__restrict__ *__restrict__ snr, /* INPUT, (2, 3) * data_points */
  int iifo, /* INPUT, detector we are considering */
  int nifo, /* INPUT, all detectors that are in this coherent analysis */
  int *__restrict__ peak_pos, /* INPUT, place the location of the trigger */
  float *__restrict__ *__restrict__ snglsnr, /* INPUT, maximum single snr */
  float *__restrict__ cohsnr, /* INPUT, coherent snr */
  int npeak, /* INPUT, number of triggers */
  float *__restrict__ u_map, /* INPUT, u matrix map */
  float *__restrict__ toa_diff_map, /* INPUT, time of arrival difference map */
  int num_sky_directions, /* INPUT, # of sky directions */
  int max_npeak, /* INPUT, max number of peaks */
  int len, /* INPUT, snglsnr length */
  int start_exe, /* INPUT, snglsnr start exe position */
  float dt, /* INPUT, 1/ sampling rate */
  int ntmplt, /* INPUT, number of templates */
  int *__restrict__ len_idx, /* INPUT, the length of the peaks */
  int *__restrict__ tmplt_idx /* INPUT, the template used for this peak */
) {

    int peak_cur, tmplt_cur, len_cur, ipeak_max;
    COMPLEX_F dk[MAX_NIFO];
    int NtOff;
    int map_idx, ipix, i;
    float real, imag;
    float snr_tmp, al_all = 0.0f;
    extern __shared__ float smem[];

    /* find maximum cohsnr and swope to the first pos */
    volatile float *cohsnr_shared = &smem[0];
    volatile float *ipeak_shared  = &smem[blockDim.x];
    float cohsnr_max              = 0.0, cohsnr_cur;

    if (npeak > 1) {
        /* clean up smem history */
        cohsnr_shared[threadIdx.x] = 0.0;
        ipeak_shared[threadIdx.x]  = 0;
        __syncthreads();
        /* load max cohsnr to smem for each thread in a block */
        for (i = threadIdx.x; i < npeak; i += blockDim.x) {
            peak_cur   = peak_pos[i];
            cohsnr_cur = cohsnr[peak_cur];
            if (cohsnr_cur > cohsnr_max) {
                cohsnr_shared[threadIdx.x] = cohsnr_cur;
                ipeak_shared[threadIdx.x]  = i;
                cohsnr_max                 = cohsnr_cur;
            }
        }
        __syncthreads();

        /* reduce the max snr to the first position */
        for (i = blockDim.x >> 1; i > 0; i = i >> 1) {
            if (threadIdx.x < i) {
                cohsnr_cur = cohsnr_shared[threadIdx.x + i];
                cohsnr_max = cohsnr_shared[threadIdx.x];

                if (cohsnr_cur > cohsnr_max) {
                    cohsnr_shared[threadIdx.x] = cohsnr_cur;
                    ipeak_shared[threadIdx.x]  = ipeak_shared[threadIdx.x + i];
                }
            }
            __syncthreads();
        }

        /* swope the first and max peak_cur in peak_pos */

        if (threadIdx.x == 0) {
            ipeak_max           = ipeak_shared[0];
            peak_cur            = peak_pos[ipeak_max];
            peak_pos[ipeak_max] = peak_pos[0];
            peak_pos[0]         = peak_cur;
        }

        __syncthreads();
    }

    /* cohsnr skymap generation */

    if (npeak > 0) {
        peak_cur = peak_pos[0];
        // find the len_cur from len_idx
        len_cur = len_idx[peak_cur];
        // find the tmplt_cur from tmplt_idx
        tmplt_cur = tmplt_idx[peak_cur];

        for (int seed_pix = threadIdx.x; seed_pix < num_sky_directions;
             seed_pix += blockDim.x) {
            snr_tmp = 0.0;
            al_all  = 0.0;
            // matrix u is stored in column order
            // mu = u_map + nifo * nifo * i;
            ipix = seed_pix;

            for (int j = 0; j < nifo; ++j) {
                /* this is a simplified algorithm to get map_idx */
                map_idx = iifo * nifo + j;
                NtOff =
                  round(toa_diff_map[map_idx * num_sky_directions + ipix] / dt);
                NtOff = (j == iifo ? 0 : NtOff);
                // dk[j] = snr[j][ring_index(start_exe + len_cur + NtOff,
                // len) * ntmplt + tmplt_cur ];
                dk[j] = snr[j][tmplt_cur * len
                               + ring_index(start_exe + len_cur + NtOff, len)];
            }

            for (int j = 0; j < nifo; ++j) {
                real = 0.0f;
                imag = 0.0f;
                for (int k = 0; k < nifo; ++k) {
                    // transpose of u
                    real += u_map[(k * nifo + j) * num_sky_directions + ipix]
                            * dk[k].re;
                    imag += u_map[(k * nifo + j) * num_sky_directions + ipix]
                            * dk[k].im;
                }
                (j < 2 ? snr_tmp : al_all) += real * real + imag * imag;
            }

            cohsnr_skymap[ipix]  = snr_tmp;
            nullsnr_skymap[ipix] = al_all;
        }
    }
}

static __host__ unsigned int bitset_count(const unsigned int bitset) {
    return __builtin_popcount(bitset);
}

static __device__ unsigned int bitset_contains(const unsigned int bitset,
                                               const int i) {
    return (bitset >> i) & 1;
}

__global__ void ker_coh_max_and_chisq_versatile(
  COMPLEX_F *__restrict__ *__restrict__ snr, /* INPUT, (2, 3) * data_points */
  int iifo, /* INPUT, detector we are considering */
  int nifo, /* INPUT, number of enabled detectors */
  int num_coh_ifos, /* INPUT, number of coherent detectors */
  unsigned int coh_ifo_bitset, /* INPUT, coherent detectors */
  int *__restrict__ write_ifo_mapping, /* INPUT, write-ifo-mapping */
  int *__restrict__ peak_pos, /* INPUT, place the location of the trigger */
  float *__restrict__ *__restrict__ snglsnr, /* INPUT, maximum single snr */
  float *__restrict__ *__restrict__ snglsnr_bg, /* INPUT, maximum single snr */
  int npeak, /* INPUT, number of triggers */
  float *__restrict__ u_map, /* INPUT, u matrix map */
  float *__restrict__ toa_diff_map, /* INPUT, time of arrival difference map */
  int num_sky_directions, /* INPUT, # of sky directions */
  int len, /* INPUT, snglsnr length */
  int max_npeak, /* INPUT, snglsnr length */
  int start_exe, /* INPUT, snglsnr start exe position */
  float dt, /* INPUT, 1/ sampling rate */
  int ntmplt, /* INPUT, number of templates */
  int autochisq_len, /* INPUT, auto-chisq length */
  COMPLEX_F *__restrict__
    *__restrict__ autocorr_matrix, /* INPUT, autocorrelation matrix for all
                                      templates */
  float *__restrict__ *__restrict__ autocorr_norm, /* INPUT, autocorrelation
                          normalization matrix for all templates */
  int hist_trials, /* INPUT, trial number */
  int trial_sample_inv, /* INPUT, trial interval in samples */
  int *__restrict__ pix_idx, /* OUTPUT, sky direction index */
  int *__restrict__ pix_idx_bg, /* OUTPUT, sky direction index for the
                                   background */
  float *__restrict__ cohsnr, /* OUTPUT, the coherent SNR for combination of
                                 detectors */
  float *__restrict__ nullsnr, /* OUTPUT, the nullsnr for the combination of
                                  detectors */
  float *__restrict__ cmbchisq, /* OUTPUT, the chisq for the combination of
                                   detectors */
  float *__restrict__ cohsnr_bg, /* OUTPUT, the coherent SNR for the background
                                    noise */
  float
    *__restrict__ nullsnr_bg, /* OUTPUT, the nullsnr for the background noise */
  float *__restrict__ cmbchisq_bg, /* OUTPUT, the combined chisq for the
                                      background noise */
  float *__restrict__ *__restrict__ coaphase,
  float *__restrict__ *__restrict__ coaphase_bg,
  int *__restrict__ *__restrict__ ntoff,
  float *__restrict__ *__restrict__ chisq,
  float *__restrict__ *__restrict__ chisq_bg,
  int *__restrict__ len_idx,
  int *__restrict__ tmplt_idx) {
    int bid = blockIdx.x;
    int bn  = gridDim.x;

    int wn  = blockDim.x >> LOG_WARP_SIZE;
    int wID = threadIdx.x >> LOG_WARP_SIZE;

    int srcLane = threadIdx.x & 0x1f, ipix; // binary: 11111, decimal 31
    // store snr_max, nullstream_max and sky_idx, each has (blockDim.x /
    // WARP_SIZE) elements
    extern __shared__ float smem[];
    volatile float *__restrict__ stat_shared       = &smem[0];
    volatile float *__restrict__ snr_shared        = &stat_shared[wn];
    volatile float *__restrict__ nullstream_shared = &snr_shared[wn];
    volatile int *__restrict__ sky_idx_shared = (int *)&nullstream_shared[wn];

    // float    *mu;    // matrix u for certain sky direction
    int peak_cur, tmplt_cur;
    COMPLEX_F dk[MAX_NIFO];
    int NtOff;
    int map_idx;
    float real, imag;
    float al_all = 0.0f, chisq_cur;

    float stat_max, stat_tmp;
    float snr_max, snr_tmp;
    float nullstream_max, nullstream_max_tmp;
    int sky_idx = 0, sky_idx_tmp = 0;
    int i, itrial, trial_offset, output_offset, len_cur;

    for (int ipeak = bid; ipeak < npeak; ipeak += bn) {
        peak_cur = peak_pos[ipeak];
        // find the len_cur from len_idx
        len_cur = len_idx[peak_cur];
        // find the tmplt_cur from tmplt_idx
        tmplt_cur = tmplt_idx[peak_cur];

        itrial         = 0;
        stat_max       = 0.0;
        snr_max        = 0.0;
        nullstream_max = 0.0f;
        sky_idx        = 0;

        for (int seed_pix = threadIdx.x;
             seed_pix < num_sky_directions / NSKY_REDUCE_RATIO;
             seed_pix += blockDim.x) {
            ipix = seed_pix * NSKY_REDUCE_RATIO;

            snr_tmp = 0.0;
            al_all  = 0.0;
            // matrix u is stored in column order
            // mu = u_map + nifo * nifo * i;

            for (int j = 0; j < nifo; ++j) {
                /* this is a simplified algorithm to get map_idx */
                map_idx = iifo * nifo + j;

                NtOff =
                  round(toa_diff_map[map_idx * num_sky_directions + ipix] / dt);
                NtOff = (j == iifo ? 0 : NtOff);
                // dk[j] = snr[j][ring_index(start_exe + len_cur + NtOff,
                // len) * ntmplt + tmplt_cur ];
                dk[j] = snr[j][tmplt_cur * len
                               + ring_index(start_exe + len_cur + NtOff, len)];
            }
            if (num_coh_ifos == 2) {
                for (int k = 0; k < nifo; ++k) {
                    snr_tmp += bitset_contains(coh_ifo_bitset, k)
                               * (dk[k].re * dk[k].re + dk[k].im * dk[k].im);
                }
                al_all = 0.0;
            } else {
                for (int j = 0; j < nifo; ++j) {
                    real = 0.0f;
                    imag = 0.0f;
                    for (int k = 0; k < nifo; ++k) {
                        // transpose of u_map
                        real +=
                          u_map[(k * nifo + j) * num_sky_directions + ipix]
                          * dk[k].re;
                        imag +=
                          u_map[(k * nifo + j) * num_sky_directions + ipix]
                          * dk[k].im;
                    }
                    (j < 2 ? snr_tmp : al_all) += real * real + imag * imag;
                }
            }

            stat_tmp = snr_tmp - 0.0;
            if (stat_tmp > stat_max) {
                stat_max       = stat_tmp;
                snr_max        = snr_tmp;
                nullstream_max = al_all;
                sky_idx        = ipix;
            }
        }

        for (i = WARP_SIZE / 2; i > 0; i = i >> 1) {
            stat_tmp = __shfl_xor_sync(ALL_THREADS_MASK, stat_max, i);
            snr_tmp  = __shfl_xor_sync(ALL_THREADS_MASK, snr_max, i);
            nullstream_max_tmp =
              __shfl_xor_sync(ALL_THREADS_MASK, nullstream_max, i);
            sky_idx_tmp = __shfl_xor_sync(ALL_THREADS_MASK, sky_idx, i);

            if (stat_tmp > stat_max) {
                stat_max       = stat_tmp;
                snr_max        = snr_tmp;
                nullstream_max = nullstream_max_tmp;
                sky_idx        = sky_idx_tmp;
            }
        }

        if (srcLane == 0) {
            stat_shared[wID]       = stat_max;
            snr_shared[wID]        = snr_max;
            nullstream_shared[wID] = nullstream_max;
            sky_idx_shared[wID]    = sky_idx;
        }
        __syncthreads();

        for (i = wn >> 1; i > 0; i = i >> 1) {
            if (threadIdx.x < i) {
                stat_tmp = stat_shared[threadIdx.x + i];
                stat_max = stat_shared[threadIdx.x];

                if (stat_tmp > stat_max) {
                    stat_shared[threadIdx.x] = stat_tmp;
                    snr_shared[threadIdx.x]  = snr_shared[threadIdx.x + i];
                    nullstream_shared[threadIdx.x] =
                      nullstream_shared[threadIdx.x + i];
                    sky_idx_shared[threadIdx.x] =
                      sky_idx_shared[threadIdx.x + i];
                }
            }
            __syncthreads();
        }
        if (threadIdx.x == 0) {
            cohsnr[peak_cur]  = snr_shared[0];
            nullsnr[peak_cur] = nullstream_shared[0];
            pix_idx[peak_cur] = sky_idx_shared[0];
        }
        __syncthreads();

        /* chisq calculation */
        cmbchisq[peak_cur] = 0.0;
        COMPLEX_F data, tmp_snr, tmp_autocorr, tmp_maxsnr;
        float laneChi2         = 0.0f;
        int autochisq_half_len = autochisq_len / 2, peak_pos_tmp;

        for (int j = 0; j < nifo; ++j) {
            laneChi2 = 0.0f;
            /* this is a simplified algorithm to get map_idx */
            map_idx = iifo * nifo + j;

            NtOff = round(
              toa_diff_map[map_idx * num_sky_directions + pix_idx[peak_cur]]
              / dt);
            NtOff        = (j == iifo ? 0 : NtOff);
            peak_pos_tmp = start_exe + len_cur + NtOff;
            tmp_maxsnr =
              snr[j][len * tmplt_cur + ring_index(peak_pos_tmp, len)];

            /* store the snglsnr and phase for each detector even the detector
             * does not participate */
            /* set the ntoff; snglsnr; and coa_phase for each detector */
            /* set the ntoff; this is actually d_ntoff_*  */
            ntoff[write_ifo_mapping[j]][peak_cur] = NtOff;
            /* set the d_snglsnr_* */
            snglsnr[write_ifo_mapping[j]][peak_cur] = sqrt(
              tmp_maxsnr.re * tmp_maxsnr.re + tmp_maxsnr.im * tmp_maxsnr.im);
            /* set the d_coa_phase_* */
            coaphase[write_ifo_mapping[j]][peak_cur] =
              atan2(tmp_maxsnr.im, tmp_maxsnr.re);

            for (int ishift = threadIdx.x - autochisq_half_len;
                 ishift <= autochisq_half_len; ishift += blockDim.x) {
                tmp_snr = snr[j][len * tmplt_cur
                                 + ring_index(peak_pos_tmp + ishift, len)];
                tmp_autocorr =
                  autocorr_matrix[j][tmplt_cur * autochisq_len + ishift
                                     + autochisq_half_len];
                data.re = tmp_snr.re - tmp_maxsnr.re * tmp_autocorr.re
                          + tmp_maxsnr.im * tmp_autocorr.im;
                data.im = tmp_snr.im - tmp_maxsnr.re * tmp_autocorr.im
                          - tmp_maxsnr.im * tmp_autocorr.re;
                laneChi2 += (data.re * data.re + data.im * data.im);
            }
            for (int k = WARP_SIZE >> 1; k > 0; k = k >> 1) {
                laneChi2 +=
                  __shfl_xor_sync(ALL_THREADS_MASK, laneChi2, k, WARP_SIZE);
            }
            if (srcLane == 0) { snr_shared[wID] = laneChi2; }
            unsigned chisq_mask = __ballot_sync(0xFFFFFFFF, threadIdx.x < wn);
            __syncthreads();
            if (threadIdx.x < wn) {
                laneChi2 = snr_shared[srcLane];
                for (i = wn / 2; i > 0; i = i >> 1) {
                    laneChi2 += __shfl_xor_sync(chisq_mask, laneChi2, i);
                }
                if (srcLane == 0) {
                    chisq_cur = laneChi2 / autocorr_norm[j][tmplt_cur];
                    // the location of chisq_* is indexed from maxsnglsnr
                    chisq[write_ifo_mapping[j]][peak_cur] = chisq_cur;
                    cmbchisq[peak_cur] +=
                      bitset_contains(coh_ifo_bitset, j) * chisq_cur;
                    // printf("peak %d, itrial %d, cohsnr %f, nullstream %f,
                    // ipix %d, chisq %f\n", ipeak, itrial, cohsnr[peak_cur],
                    // nullsnr[peak_cur], pix_idx[peak_cur],
                    // cmbchisq[peak_cur]);
                }
            }
            __syncthreads();
        }

        __syncthreads();

        /*
         *
         * Generate background cohsnr; nullsnr; chisq
         *
         */

        int ipix = 0;
        for (itrial = 1 + threadIdx.x / WARP_SIZE; itrial <= hist_trials;
             itrial += blockDim.x / WARP_SIZE) {
            snr_max        = 0.0;
            nullstream_max = 0.0;
            sky_idx        = 0;

            // FIXME: try using random offset like the following
            // rand_range = trial_sample_inv * hist_trials - 1;
            // trial_offset = rand()% rand_range + 1;
            trial_offset  = itrial * trial_sample_inv;
            output_offset = peak_cur + (itrial - 1) * max_npeak;
            for (int seed_pix = srcLane;
                 seed_pix < num_sky_directions / NSKY_REDUCE_RATIO;
                 seed_pix += WARP_SIZE) {
                snr_tmp = 0.0;
                al_all  = 0.0;
                // matrix u is stored in column order
                // mu = u_map + nifo * nifo * i;

                ipix = (seed_pix * NSKY_REDUCE_RATIO)
                       + (itrial & (NSKY_REDUCE_RATIO - 1));
                for (int j = 0; j < nifo; ++j) {
                    /* this is a simplified algorithm to get map_idx */
                    map_idx = iifo * nifo + j;

                    NtOff = round(
                      toa_diff_map[map_idx * num_sky_directions + ipix] / dt);
                    // The background cohsnr should be obtained coherently as
                    // well.
                    int offset =
                      (j == iifo ? 0 : NtOff - (trial_offset * (j - iifo)));
                    // dk[j] = snr[j][ring_index(start_exe + len_cur +
                    // offset, len) * ntmplt + tmplt_cur ];
                    dk[j] =
                      snr[j][len * tmplt_cur
                             + ring_index(start_exe + len_cur + offset, len)];
                }
                if (num_coh_ifos == 2) {
                    for (int k = 0; k < nifo; ++k) {
                        snr_tmp +=
                          bitset_contains(coh_ifo_bitset, k)
                          * (dk[k].re * dk[k].re + dk[k].im * dk[k].im);
                    }
                    al_all = 0.0;
                } else {
                    for (int j = 0; j < nifo; ++j) {
                        real = 0.0f;
                        imag = 0.0f;
                        for (int k = 0; k < nifo; ++k) {
                            // transpose of u_map
                            real +=
                              u_map[(k * nifo + j) * num_sky_directions + ipix]
                              * dk[k].re;
                            imag +=
                              u_map[(k * nifo + j) * num_sky_directions + ipix]
                              * dk[k].im;
                        }
                        (j < 2 ? snr_tmp : al_all) += real * real + imag * imag;
                    }
                }

                stat_tmp = snr_tmp - 0.0;
                if (stat_tmp > stat_max) {
                    stat_max       = stat_tmp;
                    snr_max        = snr_tmp;
                    nullstream_max = al_all;
                    sky_idx        = ipix;
                }
            }

            for (i = WARP_SIZE / 2; i > 0; i = i >> 1) {
                stat_tmp = __shfl_xor_sync(ALL_THREADS_MASK, stat_max, i);
                snr_tmp  = __shfl_xor_sync(ALL_THREADS_MASK, snr_max, i);
                nullstream_max_tmp =
                  __shfl_xor_sync(ALL_THREADS_MASK, nullstream_max, i);
                sky_idx_tmp = __shfl_xor_sync(ALL_THREADS_MASK, sky_idx, i);

                if (stat_tmp > stat_max) {
                    stat_max       = stat_tmp;
                    snr_max        = snr_tmp;
                    nullstream_max = nullstream_max_tmp;
                    sky_idx        = sky_idx_tmp;
                }
            }
            if (srcLane == 0) {
                cohsnr_bg[output_offset]  = snr_max;
                nullsnr_bg[output_offset] = nullstream_max;
                /* background need this for Ntoff */
                pix_idx_bg[output_offset] = sky_idx;
            }
            __syncthreads();

            /* c code here
            COMPLEX_F data;
            chisq[peak_cur] = 0.0;
            int autochisq_half_len = autochisq_len /2;
            for (int j = 0; j < nifo; ++j)
            {   data = 0;
                // this is a simplified algorithm to get map_idx
                map_idx = iifo * nifo + j;
                NtOff = round (toa_diff_map[map_idx * num_sky_directions + ipix]
            / dt); for(int ishift=-autochisq_half_len;
            ishift<=autochisq_half_len; ishift++)
                {

                data += snr[j][ring_index(start_exe + peak_cur + NtOff +
            ishift, len) * ntmplt + tmplt_cur] - maxsnglsnr[peak_cur] *
            autocorr_matrix[j][ tmplt_cur * autochisq_len + ishift +
            autochisq_half_len];
                }
                chisq[peak_cur] += (data.re * data.re + data.im * data.im) /
            autocorr_norm[j][tmplt_cur];
            }
            */
            COMPLEX_F data, tmp_snr, tmp_autocorr, tmp_maxsnr;
            float laneChi2         = 0.0f;
            int autochisq_half_len = autochisq_len / 2, peak_pos_tmp;

            cmbchisq_bg[output_offset] = 0.0;

            for (int j = 0; j < nifo; ++j) {
                if (!bitset_contains(coh_ifo_bitset, j)) { continue; }

                laneChi2 = 0.0f;
                /* this is a simplified algorithm to get map_idx */
                map_idx = iifo * nifo + j;
                NtOff   = round(toa_diff_map[map_idx * num_sky_directions
                                           + pix_idx_bg[output_offset]]
                              / dt);

                peak_pos_tmp =
                  start_exe + len_cur
                  + (j == iifo ? 0 : NtOff - (trial_offset * (j - iifo)));

                // tmp_maxsnr = snr[j][ring_index(peak_pos_tmp, len) *
                // ntmplt + tmplt_cur];
                tmp_maxsnr =
                  snr[j][len * tmplt_cur + ring_index(peak_pos_tmp, len)];
                /* set the d_snglsnr_* */
                snglsnr_bg[write_ifo_mapping[j]][output_offset] =
                  sqrt(tmp_maxsnr.re * tmp_maxsnr.re
                       + tmp_maxsnr.im * tmp_maxsnr.im);
                /* set the d_coa_phase_* */
                coaphase_bg[write_ifo_mapping[j]][output_offset] =
                  atan2(tmp_maxsnr.im, tmp_maxsnr.re);

                for (int ishift = srcLane - autochisq_half_len;
                     ishift <= autochisq_half_len; ishift += WARP_SIZE) {
                    // tmp_snr = snr[j][ring_index(peak_pos_tmp + ishift,
                    // len) * ntmplt + tmplt_cur];
                    tmp_snr = snr[j][len * tmplt_cur
                                     + ring_index(peak_pos_tmp + ishift, len)];
                    tmp_autocorr =
                      autocorr_matrix[j][tmplt_cur * autochisq_len + ishift
                                         + autochisq_half_len];
                    data.re = tmp_snr.re - tmp_maxsnr.re * tmp_autocorr.re
                              + tmp_maxsnr.im * tmp_autocorr.im;
                    data.im = tmp_snr.im - tmp_maxsnr.re * tmp_autocorr.im
                              - tmp_maxsnr.im * tmp_autocorr.re;
                    laneChi2 += (data.re * data.re + data.im * data.im);
                }
                for (int k = WARP_SIZE >> 1; k > 0; k = k >> 1) {
                    laneChi2 +=
                      __shfl_xor_sync(ALL_THREADS_MASK, laneChi2, k, WARP_SIZE);
                }

                if (srcLane == 0) {
                    chisq_cur = laneChi2 / autocorr_norm[j][tmplt_cur];
                    // set d_chisq_bg_* from snglsnr_bg
                    chisq_bg[write_ifo_mapping[j]][output_offset] = chisq_cur;
                    cmbchisq_bg[output_offset] += chisq_cur;
                }

                __syncthreads();
            }
            __syncthreads();
        }
    }
}

#define TRANSPOSE_TILE_DIM   32
#define TRANSPOSE_BLOCK_ROWS 8

__global__ void transpose_matrix(COMPLEX_F *__restrict__ idata,
                                 COMPLEX_F *__restrict__ odata,
                                 int in_x_offset,
                                 int in_y_offset,
                                 int in_width,
                                 int in_height,
                                 int out_x_offset,
                                 int out_y_offset,
                                 int out_width,
                                 int out_height,
                                 int copy_width,
                                 int copy_height) { // for in matrix

    // sizeof(COMPLEX_F) == 8 bytes
    // 32 shared memory banks
    __shared__ COMPLEX_F tile[TRANSPOSE_TILE_DIM][TRANSPOSE_TILE_DIM + 1];

    int x = blockIdx.x * TRANSPOSE_TILE_DIM + threadIdx.x;
    int y = blockIdx.y * TRANSPOSE_TILE_DIM + threadIdx.y;

    if (x < copy_width) {
        for (int j = 0; j < TRANSPOSE_TILE_DIM && y + j < copy_height;
             j += TRANSPOSE_BLOCK_ROWS)
            tile[threadIdx.y + j][threadIdx.x] =
              idata[((in_y_offset + y + j) % in_height) * in_width
                    + (in_x_offset + x) % in_width];
    }

    __syncthreads();

    x = blockIdx.y * TRANSPOSE_TILE_DIM + threadIdx.x; // transpose block offset
    y = blockIdx.x * TRANSPOSE_TILE_DIM + threadIdx.y;

    if (x < copy_height) {
        for (int j = 0; j < TRANSPOSE_TILE_DIM && y + j < copy_width;
             j += TRANSPOSE_BLOCK_ROWS)
            odata[((out_y_offset + y + j) % out_height) * out_width
                  + (out_x_offset + x) % out_width] =
              tile[threadIdx.x][threadIdx.y + j];
    }
}

void transpose_snglsnr(COMPLEX_F *idata,
                       COMPLEX_F *odata,
                       int offset,
                       int copy_snglsnr_len,
                       int snglsnr_len,
                       int tmplt_len,
                       cudaStream_t stream) {
    // input shape [height, width] [copy_snglsnr_len, tmplt_len]
    // output shape [snglsnr_len, tmplt_len]^T
    dim3 grid((tmplt_len + TRANSPOSE_TILE_DIM - 1) / TRANSPOSE_TILE_DIM,
              (copy_snglsnr_len + TRANSPOSE_TILE_DIM - 1) / TRANSPOSE_TILE_DIM);
    dim3 block(TRANSPOSE_TILE_DIM, TRANSPOSE_BLOCK_ROWS);
    transpose_matrix<<<grid, block, 0, stream>>>(
      idata, odata, 0, 0, tmplt_len, copy_snglsnr_len, offset, 0, snglsnr_len,
      tmplt_len, tmplt_len, copy_snglsnr_len);
}

/* calculate cohsnr, null stream, chisq of a peak list and copy it back */
void cohsnr_and_chisq(PostcohState *state,
                      unsigned int coh_ifo_bitset,
                      int iifo,
                      int gps_idx,
                      int output_skymap,
                      cudaStream_t stream) {
    int threads = 256;
    int sharedsize =
      MAX(2 * threads * sizeof(float), 4 * threads / WARP_SIZE * sizeof(float));
    PeakList *pklist = state->peak_list[iifo];
    int npeak        = pklist->npeak[0];

    ker_coh_max_and_chisq_versatile<<<npeak, threads, sharedsize, stream>>>(
      state->dd_snglsnr, iifo, state->nifo, bitset_count(coh_ifo_bitset),
      coh_ifo_bitset, state->d_write_ifo_mapping, pklist->d_peak_pos,
      pklist->d_snglsnr, pklist->d_snglsnr_bg, pklist->npeak[0],
      state->d_U_map[gps_idx], state->d_diff_map[gps_idx], state->npix,
      state->snglsnr_len, state->max_npeak, state->snglsnr_start_exe, state->dt,
      state->ntmplt, state->autochisq_len, state->dd_autocorr_matrix,
      state->dd_autocorr_norm, state->hist_trials, state->trial_sample_inv,
      pklist->d_pix_idx, pklist->d_pix_idx_bg, pklist->d_cohsnr,
      pklist->d_nullsnr, pklist->d_cmbchisq, pklist->d_cohsnr_bg,
      pklist->d_nullsnr_bg, pklist->d_cmbchisq_bg, pklist->d_coaphase,
      pklist->d_coaphase_bg, pklist->d_ntoff, pklist->d_chisq,
      pklist->d_chisq_bg, pklist->d_len_idx, pklist->d_tmplt_idx);

    CUDA_CHECK(cudaStreamSynchronize(stream));
    CUDA_CHECK(cudaPeekAtLastError());

    if (output_skymap && state->snglsnr_max[iifo] > output_skymap) {
        ker_coh_skymap<<<1, threads, sharedsize, stream>>>(
          pklist->d_cohsnr_skymap, pklist->d_nullsnr_skymap, state->dd_snglsnr,
          iifo, state->nifo, pklist->d_peak_pos, pklist->d_snglsnr,
          pklist->d_cohsnr, pklist->npeak[0], state->d_U_map[gps_idx],
          state->d_diff_map[gps_idx], state->npix, state->max_npeak,
          state->snglsnr_len, state->snglsnr_start_exe, state->dt,
          state->ntmplt, pklist->d_len_idx, pklist->d_tmplt_idx);

        CUDA_CHECK(cudaStreamSynchronize(stream));
        CUDA_CHECK(cudaPeekAtLastError());

        CUDA_CHECK(cudaMemcpyAsync(
          pklist->cohsnr_skymap, pklist->d_cohsnr_skymap,
          sizeof(float) * state->npix * 2, cudaMemcpyDeviceToHost, stream));
    }

    /* copy the snr, cohsnr, nullsnr, chisq out */
    CUDA_CHECK(cudaMemcpyAsync(pklist->snglsnr[0], pklist->d_snglsnr[0],
                               sizeof(float) * (pklist->peak_floatlen),
                               cudaMemcpyDeviceToHost, stream));

    CUDA_CHECK(cudaMemcpyAsync(pklist->npeak, pklist->d_npeak,
                               sizeof(int) * (pklist->peak_intlen),
                               cudaMemcpyDeviceToHost, stream));

    CUDA_CHECK(cudaStreamSynchronize(stream));
    CUDA_CHECK(cudaPeekAtLastError());
}
